<?php
var datepicker = $.fn.datepicker.noConflict(); // return $.fn.datepicker to previously assigned value
$.fn.bootstrapDP = datepicker;                 // give $().bootstrapDP the bootstrap-datepicker functionality
$ lessc build/build_standalone.less datepicker.css
$('.datepicker').datepicker();


$actividades=['Turismo en Bicicleta','Rafting','Sock cultural','Tour vino y comida','Moto Tour','Montañismo','Safari','Navegacion','Snorkeling','Sky',
'Trekking','Voluntariado','Ecologico']


$paises=['Afganistan','Albania','Algeria','Andorra','Angola','Anguilla','Antarctica','Antigua y Barbuda','Arabia Saudita','Argentina'
'Armenia','Aruba','Australia','Austria','Azerbaijan','Bahamas','Bahrain','Bangladesh','Barbados','Belarus','Belgica','Belize','Benin','Bermuda','Bhutan','Bolivia'
'Bosnia yHerzegovina','Botswana','Brazil','Brunei','Bulgaria','Burkina Faso','Burundi','Cambodia','Cameroon','Canada','Cape Verde',
'Central African Republic','Chad','Chile','China','Islas Caiman','Isla Cocos','Islas Cook','Colombia','Comoros','Congo',
'Costa Rica','Croatia','Cuba','Cyprus','Czech Republic','Democratic Republic of the Congo (Kinshasa)','Denmark','Djibouti','Republica Dominicana','East Timor Timor-Leste','Ecuador','Egypt','El Salvador','Equatorial Guinea','Eritrea','Estonia','Ethiopia','Falkland Islands','Faroe Islands,
Fiji','Finland','Francia','Polinesia','Gabon','Gambia','Georgia','Alemania','Ghana','Gran Bretaña',
'Grecia','Greenland','Granada','Guadeloupe','Guam','Guatemala','Guinea','Guyana','Haiti','Holy See','Honduras','Hong Kong','Hungria','Iceland','India','Indonesia','Iran','Iraq','Irlanda','Israel','Italia','Jamaica','Japón','Jordania','Kazakhstan',
'Kenya','Kiribati','Korea', 'Korea del Norte','Korea', 'Korea del sur','Kosovo','Kuwait','KyrgyzstanLao','Latvia','Lebanon','Lesotho','Liberia','Libya','Liechtenstein','Lithuania','Luxembourgo','Macao','Macedonia',
'Madagascar','Malawi','Malasia','Maldivas','Mali','Malta','Mauritania','Mauritius','Mayotte','Mexico','Micronesia', 'Mongolia','Montenegro','Montserrat','Morocco','Mozambique','Myanmar', 'Burma','Namibia','Nauru','Nepal','Netherlands','Antillas',
'Nueva Zelanda','Nicaragua','Niger','Nigeria','Niue','Norway','Oman','Pakistan','Palau','Panama','Paraguay','Peru','Philipinas','Polonia','Portugal','Puerto Rico','Qatar','Romania','Rusia','Rwanda','Samoa','San Marino','Senegal','Serbia','Seychelles',
'Sierra Leona','Singapur','Slovakia','Slovenia','Somalia','South Africa','España','Sri Lanka','Sudan','Suriname','Swaziland',
'Suecia','Swisa','Syria','Taiwan ','Tajikistan','Tanzania','Tailandia','Tibet','Togo',
'Tokelau','Tonga','Tunisia','Turkia','Turkmenistan','Turks and Caicos','Tuvalu','Uganda','Ucrania','Emiratos Arabes','United Kingdom',
'Uruguay','Uzbekistan','Vanuatu','Vatican City State (Holy See)','Venezuela','Vietnam','Virgin Islands (British)','Virgin Islands (U.S.)','Wallis and Futuna Islands',
'Sahara','Yemen','Zambia','Zimbabwe']

<?php foreach ($paises as $value): ?>
<?php if ($value == $pais): ?>
<option selected value="<?=$value?>"><?=$value?></option>
<?php else: ?>
<option value="<?=$value?>"><?=$value?></option>
<?php endif; ?>
<?php endforeach; ?>

<?php foreach ($actividades as $value): ?>
<?php if ($value == $actividades): ?>
<option selected value="<?=$value?>"><?=$value?></option>
<?php else: ?>
<option value="<?=$value?>"><?=$value?></option>
<?php endif; ?>
<?php endforeach; ?>

//validacion del formulario//
<?php
function validar($data){
    $textmensaje = trim($data['textmensaje']);
    $datein = trim($data['date-in']);
    $dateout = trim($data['date-out']);
    $flexsi = trim($data['flex-si']);
    $flexno = trim($data['flex-no']);
    $pais=    trim($data['pais']);
    $ciudad=  trim($data['ciudad']);
    $mensajeiti= trim($data['mensajeiti']);
    $importe= trim($data['importe']);
    $moneda= trim($data['moneda']);
    $errores = [];

    if ($textmensaje == '') {
            $errores['textmensaje']  = 'Por favor compelta el nomre de tu viaje';
        }
    if ($datein == '') {
            $errores['datein']  = 'Por favor compelta la fecha salida';
        }
    if ($dateout == '') {
              $errores['dateout']  = 'Por favor compelta la fecha de regreso';
        }
    if ($flexsi == '') {
              $errores['flexsi']  = 'Por favor indica cuan flexible sos';
        }
    if ($pais == '') {
              $errores['pais']  = 'Por favor indica el País al que viajas';
       }
    if ($ciudad == '') {
              $errores['ciudad']  = 'Por favor indica la ciudad a visitar';
       }
    if ($importe == '') {
              $errores['importe']  = 'Por favor indica tu presupuesto';
      }
    if ($moneda == '') {
              $errores['moneda']  = 'Por favor indica que moneda presupuestas';
      }

   function guardarViaje($data,$archivo){
      $viaje=[
        "textmensaje" -> $data['textmensaje'],
        "datein" ->$data['datein'],
        "dateout" ->$data['dateout'],
        "pais" ->$data['pais'],
        "actividades" ->$data['actividades'],
        "ciudad" ->$data['ciudad'],
        "mensajeiti" ->$data['mensajeiti'],
        "importe" ->$data['importe'],
        "moneda" ->$data['moneda'],
      ];

    $viajeJSON= json_encode($viaje);

    file_put_contents('viajes.jason', $viajeJSON . PHP_EOL, FILE_APPEND);
  }



  
?>
